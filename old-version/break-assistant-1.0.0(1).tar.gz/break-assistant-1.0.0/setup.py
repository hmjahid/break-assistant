#!/usr/bin/env python3
"""Setup script for Break Assistant."""

from setuptools import setup

if __name__ == "__main__":
    setup() 